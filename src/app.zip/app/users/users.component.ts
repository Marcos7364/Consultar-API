import { Component } from '@angular/core';

@Component({
  selector: 'app-users',
  template: `
    <h2>Users</h2>
    <!-- Add your users component content here -->
  `
})
export class UsersComponent {
  // Add your component logic here
}