export class Auth {
  // Implementación mínima o real según tus necesidades
}
