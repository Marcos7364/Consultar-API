export interface Libro {
  id?: number;
  titulo: string;
  autor: string;
  descripcion: string;
  precio: number;
  stock: number;
  // Añade más propiedades según tu modelo de datos
}