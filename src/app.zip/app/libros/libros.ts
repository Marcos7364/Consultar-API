import { Component } from '@angular/core';

@Component({
  selector: 'app-libros',
  standalone: false,
  templateUrl: './libros.html',
  styleUrl: './libros.css'
})
export class Libros {

}
